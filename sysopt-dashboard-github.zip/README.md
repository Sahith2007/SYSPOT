# SYSPOT – System Performance Dashboard (Task Manager Style)

✅ Live dashboard for monitoring CPU, RAM, Disk, and Network usage using Python + Flask + Chart.js.

## 💻 How to Run

### Backend (Flask API)
```bash
cd backend
pip install -r requirements.txt
python app.py
```

> Runs at http://localhost:5000/api/stats

### Frontend (Static Dashboard)
Just open `frontend/index.html` in your browser.

> Edit `frontend/script.js` if you want to change the backend API URL (e.g., for Netlify or IP access).

## 🌍 Deploy to Netlify
1. Zip or upload the `frontend/` folder to [Netlify](https://netlify.com)
2. If backend is running elsewhere, edit `script.js` and point to your public backend URL (e.g. via Ngrok or Render).

## 📂 Project Structure
```
sysopt-dashboard-github/
├── backend/       ← Flask API (psutil)
├── frontend/      ← Static HTML dashboard
├── README.md
└── .gitignore
```

## 📊 Features
- Live CPU/RAM/Disk/Network stats
- Charts for CPU & RAM (30-point rolling)
- Dark mode design

## 🚀 Want more?
- Add GPU/process stats (via `psutil` or `GPUtil`)
- Host backend on Railway/Render/Heroku