from flask import Flask, jsonify
from flask_cors import CORS
import psutil
import time

app = Flask(__name__)
CORS(app)

def get_network_bytes():
    io = psutil.net_io_counters()
    return {"sent": io.bytes_sent, "recv": io.bytes_recv}

@app.route("/api/stats")
def stats():
    cpu_percent = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    net = get_network_bytes()

    return jsonify({
        "timestamp": int(time.time() * 1000),
        "cpu_percent": cpu_percent,
        "cpu_per_core": psutil.cpu_percent(interval=None, percpu=True),
        "ram_used": ram.used // (1024 * 1024),
        "ram_total": ram.total // (1024 * 1024),
        "ram_percent": ram.percent,
        "disk_percent": disk.percent,
        "net_sent": net['sent'],
        "net_recv": net['recv']
    })

if __name__ == "__main__":
    # Use host 0.0.0.0 so it is reachable from same PC in browsers
    app.run(host="0.0.0.0", port=5000, debug=True)